### this code deliberately uses a lot of if-else constructs for demonstration; actually it could be much simpler
import random
import time # to take it slowly

### variables to use

num_of_reps = 100 # how many times should we run the simulation
change = False # change to the alternative (True) or not change (False; stay with original choice)

# we start with zero cars and goats, then count how many are won from either
cars = 0
goats = 0

### below the simulation
count = 0
while count < num_of_reps: # repeat simulation the predefined number of times
    count = count + 1
    behind_doors = ['goat', 'goat', 'car']
    random.shuffle(behind_doors)

    # randomly choose a door (1, 2, or 3)
    choice = random.randint(1,3)

    if behind_doors[choice-1] == 'car': 
        if choice == 1:
            random_goat_door = random.choice([2, 3])
            if random_goat_door == 2: 
                alternative_choice = 3
            else: 
                alternative_choice = 2
        elif choice == 2:
            random_goat_door = random.choice([1, 3])
            if random_goat_door == 1:
                alternative_choice = 3
            else:
                alternative_choice = 1
        else: 
            random_goat_door = random.choice([1, 2])
            if random_goat_door == 1:
                alternative_choice = 2
            else:
                alternative_choice = 1
    else: 
        if choice != 1 and behind_doors[0]=='goat': 
            if choice == 2: 
                alternative_choice = 3
            else: 
                alternative_choice = 2
        elif choice != 2 and behind_doors[1]=='goat': 
            if choice == 1:
                alternative_choice = 3
            else:
                alternative_choice = 1
        else:  
            if choice == 1:
                alternative_choice = 2
            else:
                alternative_choice = 1
                
    # make the final choice (change to alternative or not, depending on the setting)
    if change: # if not, choice stays the same
        choice = alternative_choice 

    if behind_doors[choice - 1] == 'car': # if it's a car, we get a car, if not, we get a goat
        print(count, 'You got a car!')
        cars += 1 
    else:
        print(count, 'You got a goat!')
        goats += 1
        
    time.sleep(0.005) # rest a little after each repetition # 0.005

print('\x1b[2J') # clear console
time.sleep(0.5) # wait for the console clearing
print('After ' + str(num_of_reps) + ' games, we have won ' + str(cars) + ' cars and ' + str(goats) + ' goats.\nThis means a car ratio of ' + str(cars/num_of_reps) + '!', sep = '')