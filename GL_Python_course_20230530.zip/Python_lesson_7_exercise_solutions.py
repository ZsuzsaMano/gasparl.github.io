
# 1a Write a rock�paper�scissors script. The user choses, through input, "rock", "paper", or "scissors". The computer choses one randomly. Then you evaluate the outcome (who won, the user or the computer): rock beats scissors, scissors beat paper, paper beat rock. Print out the winner.

# solution

import random

user_choice = ''
ai_choice = '' 
nr_games = ai_points = user_points = 0
 
while nr_games < 3:
    nr_games += 1
    print('\n\n----------------------- ROUND: ',nr_games,' -----------------------')
    user_choice = input('\nRock, paper or scissors?: ').lower()
    while user_choice in ('rock', 'paper','scissors'):
        print('Invalid Input')
        user_choice = input('\nRock, paper or scissors?: ').lower()
    ai_choice = random.choice(['rock', 'paper','scissors'])
    print('--> You chose: ',user_choice.upper(),' and the AI chose: ',ai_choice.upper())  
    if user_choice == 'rock':
        if ai_choice == 'rock':
            print("\n\nIt's a draw! No points for anyone.")
        elif ai_choice == 'paper':
            print("\n\nThe AI wins. You lose this round!")
            ai_points += 1
        else:
            print("\n\nYou won this round!")
            user_points += 1
    elif user_choice == 'paper':
        if ai_choice == 'paper':
            print("\n\nIt's a draw! No points for anyone.")
        elif ai_choice == 'scissors':
            print("\n\nThe AI wins. You lose this round!")
            ai_points += 1
        else:
            print("\n\nYou won this round!")
            user_points += 1
    else:
        if ai_choice == 'scissors':
            print("\n\nIt's a draw! No points for anyone.")
        elif ai_choice == 'rock':
            print("\n\nThe AI wins. You lose this round!")
            ai_points += 1
        else:
            print("\n\nYou won this round!")
            user_points += 1
print('\n\n----------------------- END OF THE GAME -----------------------')
print('\n\nYour score is', user_points, 'wins out of 3 games!')
if user_points < 2:
    print('\nThe AI wins.')
else:
    print('\nCONGRATULATIONS! You are the winner.')        
        

# 4a: Create an encryption function. Takes any text (meaningful words or sentences) and converts it into an unreadable format, which cannot be understood without decryption (conversion back to the original humanly readable text). Make it as complex as possible (within reason) to prevent easy third-party decryption (i.e., others finding out how to convert the encrypted messages back to the original ones.) Assume that the original message will always consist of only the characters of the simple English alphabet (A-Z, a-z) and number digits (0-9). (Note: even if you do not write it, this code must be at least theoretically possible to decrypt!)


plaintext    = list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
encrytedtext = list('DEFGHIJKLMNOPQRSTUVWXYZABC')

def message(text, plain, encryp):
    dictionary = dict(zip(plain, encryp))
    newmessage = ''
    for char in text:
        try:
            newmessage += dictionary[char]
        except:
            newmessage += ' '
    print(text, '\nhas been encrypted to:')
    print(newmessage)