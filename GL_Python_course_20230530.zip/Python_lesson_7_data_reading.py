my_data = open('Python_lesson_7_example_data.txt', 'r')
line1 = (my_data.readline() ) # returns the first line (stored in line1) and move to the next line
print(line1)
# the trick for any data table file is to split each line with whatever separator it uses between the columns
# in this case (as usual) it's tabs, so the separator is the special character '\t'
line1_split = line1.split('\t')
print(line1_split) # prints a list of elements, which are here the column titles
# now you can access column element (in the given line) by index
print('first column:', line1_split[0]) # first element is the first column
print('second column:', line1_split[1])
print('seventh column:', line1_split[6]) # here is e.g. the response key
# remember that, if this script is executed, here we are at the second line
# now, from this second line, let's get the first column (subject_id value)
current_subject = my_data.readline().split('\t')[0] # returns line, splits it, gets first element
print(current_subject)
# position is now at the end of second line
# if we read some more data, we'll get it from the beginning of the third line
print(my_data.read(18)) # returns next 18 characters
# let's get back to the beginning
my_data.seek(0)
# we can also check the position; should be 0 after .seek(0)
print( my_data.tell() ) # the tell() method returns the number of characters before the current position
print(my_data.read(18)) # read again, now should give column titles
print( my_data.tell() ) # should be 18 now

# normally you don't need all this, you just go through each line with a for loop. you just do 'for line in file_object' - same as 'for line in file_object.readlines()'; the first is an iterable and the other is a simple list, but in a for loop they behave the same way

my_data.seek(0) # first make sure we are at the beginning
reaction_times = [] # in this list i'll collect RTs
reaction_times_irrelevant = [] # RTs for irrelevant stim_type only
print('HERE WE ARE -------------')
for line in my_data: ##  could be my_data.readlines() too
    print(line) # this is the currently read line
    columns = line.split('\t') # now i split line to get each value as separate elements of a list
    if columns[2].isdigit(): # only take lines with number in the third column (skip first, title row, and any other later on)
        reaction_times.append(columns[7]) # collect all RTs from 8th column
        if columns[5].startswith('irrelevant'):
            reaction_times_irrelevant.append(columns[7]) # collect irrelevant RTs
my_data.close()
print("all RTs:", reaction_times)
print("irrelevant RTs:", reaction_times_irrelevant)

