dict_en_de={'apple':'Apfel', 'pear':'Birne', 'kiwi':'Kiwi'} # base dictionary items

def update_word():
    print('\nYou chose to add a new word or modify an existing one. \nFirst write the English word then the German word.')
    new_en = input('English word: ')
    new_de = input('German translation: ')
    dict_en_de[new_en] = new_de
    print('You successfully added the ' + new_en + '-' + new_de + ' (English-German) word pair.')

def remove_word():
    to_remove = input('Enter the (English) word that you would like to remove.\n')
    if to_remove in dict_en_de:
        del dict_en_de[to_remove]
        print('\nYou successfully deleted the word "' + to_remove + '".')  
    else:
        print('\nWord not found in this dictionary.')

def use_dictionary():
    while True:
        user_action=input('Enter an English word to find its German translation; enter "u" (update) to add a new word or modify an existing one; enter "r" to remove a word; enter "q" to quit.\n\n')
        if user_action=='':
            continue
        if user_action=='q':
            break
        elif user_action=='u':
            update_word() # using my own function
        elif user_action=='r':
            remove_word() # using another of my own functions
        elif user_action in dict_en_de:
            print('\nThe German translation is: ', dict_en_de[user_action] )
        else:
            print('\nWord not found in this dictionary.\n')