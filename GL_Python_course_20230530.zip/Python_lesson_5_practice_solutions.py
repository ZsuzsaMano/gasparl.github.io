#1:
var = input("some word: ")
word_part = ''
for char in var:
    if char in 'xy':
        break
    if char in 'abc':
        continue
    print('---', char)
    word_part += char
    print(word_part)

#2:
import copy

l_of_ls = [[3,4,2],['a',3,44],[2,3],[3,'asdf']]

for sublist in l_of_ls:
    for element in sublist:
        print(element)

c_shallow = l_of_ls[:]  # l_of_ls.copy()
c_deep = copy.deepcopy(l_of_ls)

c_shallow[1][0] = 'new_in_shallow'
c_deep[1][2] = 'new_in_deep'

for indx, sublist in enumerate(l_of_ls):
    print("\n", sublist)
    print(c_shallow[indx])
    print(c_deep[indx])

#3:
var = input("yet another word: ")
var = list(var)

for i, char in enumerate(var):
    if char == 'e':
        var[i] = 'X'
var = ''.join(var)
print(var)

#4:
nums =[1,6,4,3,4,5,70]
new_list = []

for number in nums:
    if number < 5:
        print(number)
        new_list.append(number)
print('new list:', new_list)
