# if you want to do some python exercises for yourself...

#%% BASICS (1-3)


# 1a Write a rock�paper�scissors script. The user choses, through input, "rock", "paper", or "scissors". The computer choses one randomly. Then you evaluate the outcome (who won, the user or the computer): rock beats scissors, scissors beat paper, paper beat rock. Print out the winner.

# 1b Make it three games in a row and then display final results. (The one with the more wins - 2 or 3 - is the overall winner.)


# 2a: Revision quiz: make at least three pairs of questions and answers (e.g. "Capital city of Austria?" - "Vienna"), and display the questions in random order, requiring answer as user input. The input must match the answer exactly. Give feedback about whether or not the input was correct, and repeat all questions in a new round if any of the answers was incorrect in the previous round.

# 2b: At the end (after an all-correct round), display how many rounds (all questions displayed) it took to get all answers correctly. Furthermore, display, for each round, the ratio of correct responses.


# 3: Create a text-based adventure game. You may write it in any way you wish, as long as it makes sense.


#%% INTERMEDIATE (4-5)


# 4a: Create an encryption function. Takes any text (meaningful words or sentences) and converts it into an unreadable format, which cannot be understood without decryption (conversion back to the original humanly readable text). Make it as complex as possible (within reason) to prevent easy third-party decryption (i.e., others finding out how to convert the encrypted messages back to the original ones.) Assume that the original message will always consist of only the characters of the simple English alphabet (A-Z, a-z) and number digits (0-9). (Note: even if you do not write it, this code must be at least theoretically possible to decrypt!)

# 4b: Write a corresponding decryption function that converts the encrypted text back into the original message.


# 5a: Create a Simon memory game. Display a pattern by showing and removing (in the console) one line per one second. This line should first contain 4 underscores, separated by spaces. In the next four repetitions, in each case it should contain an X in the place of one of the four underscores. (Each time, it should have equal chances to appear at any of the four places.) Then the user should repeat back the pattern by entering a corresponding keypress pattern it into an input. The simplest way is probably to use corresponding numbers (1, 2, 3, 4) as input text - then the pattern (key positions) of numbers will also correspond to the first, second, third, and fourth underscore position. The input is then checked, and feedback is given whether or not the input pattern matched the displayed pattern.
# Example pattern, including empty start line (each new line would appear separately, with all previous one cleared away):
# _ _ _ _
# _ _ X _
# _ X _ _
# _ X _ _
# _ _ _ X
# Now the correct user input (if using numbers) is: 3224
# Hint: remember, you can clear the console using print('\x1b[2J').

# 5b: If the input did not fully match the displayed pattern, print the number of times out of the 4 repetitions where it did match the given X position. (E.g., in the example above, 3214 would match 3 out of the 4 positions. 4113 would match 0 out of the 4 positions.)

# 5c: Make all this into a function, where you can give, as arguments, (1) the number of possible positions (i.e., number of underscores where the X can appear), and (2) the number of repeatitions (i.e., how many lines with a randomly placed X are displayed).

# 5d: Extend the game: if the input did not fully matched the displayed pattern, display a new pattern with one more repetition then previously. When finally the pattern is failed, print out the detailed results (how many correct out of how many repetitions in each case).

# 5e: Modify the game in a way that not only 1, but 2, or any number of X characters can be displayed in one line at the same time. The user then may give feedback with potentially several numbers for one line and separate them e.g. with a space (or with Enter, in separate inputs).
# Example pattern, including empty start line:
# _ _ X
# X X _
# X X X
# _ X _
# Now the correct user input (if separated by spaces) is: 3 12 123 2



#%% ADVANCED (6)  


# 6a: Try creating a 3 by 3 tic-tac-toe game (Xs and Os; https://en.wikipedia.org/wiki/Tic-tac-toe). User plays with the computer. Computer choses either randomly. Hint: you can display the 3x3 table by three rows of 3 characters. E.g., an empty row with underscores (_ _ _) , and replacing ones that are chosen (e.g., _ X O). So at one point it may look like this (where player with Xs won):
# _ _ X
# O X X
# X O O

# 6b: Give an option to set the level of difficulty: computer can then make optimal choices, e.g. at least putting in a third mark whenever it has already two in a line with the third place empty.





