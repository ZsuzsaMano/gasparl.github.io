#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# this script takes positive-negative ratings from a user for words, and then calculates the 15 most positive and 15 most negative rated words

from psychopy.visual import Window, TextStim, RatingScale
from psychopy.core import wait
from psychopy.event import waitKeys
from random import shuffle
from time import strftime, gmtime
from codecs import open

# experimental stimuli
pos_words = [u'SPANNEND',u'ERINNERN',u'WÜNSCHEN',u'AKTIV',u'TAPFER',u'REIZVOLL',u'ENTDECKEN',u'MÖGEN',u'GENIE',u'TALENT',u'STARK',u'GRANDIOS',u'LEBENDIG',u'INTENSIV',u'ANSPORN',u'STAUNEN',u'REICHTUM',u'GRINSEN',u'MUNTER',u'GEBURTSTAG',u'TRIUMPH',u'FEIERN',u'HELD',u'PARTY',u'BEGEISTERN',u'RETTEN',u'MUTIG',u'FREUEN',u'FLIRT',u'EKSTASE',u'SPENDE',u'VERBESSERN']
neg_words = [u'NAIV',u'BEREUEN',u'MIETE',u'UNFAIR',u'SCHWACH',u'FORDERUNG',u'PRIMITIV',u'ALLEIN',u'VERZICHT',u'MONOTON',u'MÜSSEN',u'FEHLEN',u'KÜNDIGEN',u'ZÖGERN',u'BITTER',u'NARBIG',u'SCHLAPP',u'SCHLIESSEN',u'HÄNGEN',u'LOCH',u'AAS',u'SPUCKEN',u'SCHMUTZ',u'BALLAST',u'MAUL',u'TRETEN',u'STOTTERN',u'WARTEREI',u'ABSTIEG',u'REGLOS',u'STRAFE',u'GRAUSAM',u'SCHEUSAL']

# shorten for testing
pos_words = pos_words[:8]
neg_words = neg_words[:8]

all_words = pos_words + neg_words
shuffle(all_words)
win = Window([1200, 600], color="black", fullscr = 0, units = 'pix', allowGUI = True, screen = 1) # units = 'pix' means that objects on this window will have pixels as units - for all dimensions, such as height, length, etc.
instruction_color = 'lightblue'
instruction_page = TextStim(win, wrapWidth = 1140, height = 30, font='Verdana', color = instruction_color) # wraps at 1140 pixels

instructions_before_rating = (u'------------- INSTRUKTIONEN ZUM VALENZ RATING -------------\n\n\nDu wirst gleich eine Skala sehen, über der ein Wort angezeigt wird. Bitte bewerte dieses Wort - und alle folgenden - danach, wie \nPOSITIV bzw. NEGATIV du es empfindest (Es gibt kein Zeitlimit)!\n\nNutze dafür die abgebildete 10-Punkte-Skala von "sehr negativ" \nbis "sehr positiv". Führe den Mauszeiger an die gewünschte Stelle. Ein blaues Dreieck markiert den Wert Deines Ratings.\n\nUm Deine Wahl zu bestätigen, drücke ein Mal die linke Maustaste.\nDas Wort erscheint dann auf der jeweiligen Seite unterhalb der Skala.\n\nWeiter mit der Leertaste.')

def main():
    show_instruction( instructions_before_rating )
    create_file()
    do_ratings()
    show_instruction( "Awesome, goodbye!\n(Press space to quit.)" )
    print("Here are all the correctly positively rated words:", pos_rated, "\nHere are all the correctly negatively rated words:", neg_rated) # here we have the main results
    # the pos_rated and neg_rated lists can now be used in a response-time test

def do_ratings():
    global pos_rated, neg_rated
    scale_question = TextStim(win, color=instruction_color, font='Verdana', text = u'\nBitte bewerte die Valenz jedes Wortes mit Hilfe der abgebildeten 10-Punkte-Skala! (Bewege den Cursor auf der Linie an die entsprechende Stelle und bestätige mit einem Mausklick.)', pos = [0,170], height=33, bold = False, wrapWidth=800, colorSpace='rgb') # position, height, wrap, all in pixels
    scale_word = TextStim(win, color=instruction_color, font='Verdana', text = u'...', pos = [0,-50], height=36, bold = True, wrapWidth=1500 ) 
    new_scale = RatingScale(win=win, low=1, high = 10, scale=u"", 
                labels= ('sehr negativ','sehr positiv'), marker='triangle', skipKeys='tab', acceptPreText='', 
                lineColor = instruction_color, markerColor = instruction_color, textColor=instruction_color, textSize=0.8, singleClick = True, 
                pos = (0, -150), stretch = 2, mouseOnly = True
                )
    pos_rated = []
    neg_rated = []
    for wrd in all_words:    
        new_scale.reset()
        scale_word.setText(wrd)
        while new_scale.noResponse:
            scale_question.draw()
            scale_word.draw()
            new_scale.draw()
            win.flip()
            rat = new_scale.getRating()
            rt_scale = new_scale.getRT()
        rat = new_scale.getRating()
        rt_scale = new_scale.getRT()        
        if rat < 6: #if the rating lies between 1 and 5 -> it's stored as negative - otherwise, it is discarded from the RT Experiment's stimulus list
            if wrd in neg_words:
                neg_rated.append( (wrd, rat) )
        else:
            if wrd in pos_words:
                pos_rated.append( (wrd, rat) )
        add_rating(wrd, rat, rt_scale) # stores current rating
    ## Takes only the 15 most extremely rated from each valence category (most negative and most positive)
    shuffle(pos_rated) # shuffle things up a bit
    shuffle(neg_rated)
    pos_rated.sort(key=lambda tup: tup[1], reverse=True)  # sorts list of tuples based on second value (rating)
    neg_rated.sort(key=lambda tup: tup[1])
    del pos_rated[15:] 
    del neg_rated[15:]

def add_rating(rated_word, ratng, rt_sc): # output to save ratings
    if rated_word in pos_words:
        word_valence = 'positive'
    else:
        word_valence = 'negative'
    data_out.write(  rated_word + '\t'+ word_valence +  '\t' +  str(ratng) + '\t'+ str(rt_sc)+ '\t'+ str(strftime("%Y%m%d%H%M%S", gmtime())) + '\n'  )
    print("word:", rated_word, "rating:", ratng, "valence:", word_valence, "RT:", rt_sc)

def show_instruction(instruction_text, wait_time = 0.1):
    instruction_page.setText(instruction_text)
    instruction_page.draw()
    win.flip()
    wait(wait_time)
    inst_resp = waitKeys(keyList = ['space'])

# create output file, begin writing (column titles)
def create_file():
    global data_out
    data_out=open('likert_demo.txt', 'a', encoding="utf-8")
    data_out.write( "word_shown\tvalence\trating\trt\tdate_in_ms\n" )
    print("File created.")

# EXECUTE
main()
